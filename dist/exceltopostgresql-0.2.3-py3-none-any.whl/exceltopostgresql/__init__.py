# -*- coding:utf-8 -*-
##############################################################
# Created Date: Friday, December 3rd 2021
# Contact Info: luoxiangyong01@gmail.com
# Author/Copyright: Mr. Xiangyong Luo
##############################################################


from ._model import *

# from .exceltopostgresql import *

print("version 0.2.3")